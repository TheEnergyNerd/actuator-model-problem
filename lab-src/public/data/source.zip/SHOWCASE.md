# Atlas manipulation showcase

The new demonstration is a continuous Isaac Lab sequence: grasp, lift, rotate 90 degrees, transfer between two Franka grippers, place, release, and withdraw. The cube is supported by physical contacts. No object pose/velocity writes, attachment constraints, or episode resets occur during a recorded run.

This is a scripted task-space controller with Atlas FOC arm actuators, **not** a learned dexterous-hand policy or a Rubik's Cube solver. The Allegro page retains the existing reorientation diagnostic, and the independent Allegro training job remains separate.

## Evidence

- Nominal: all four measured stages pass, including four seconds of right-only contact support. Final cube placement error: 2.8 mm.
- Kv ×0.5 and ×2: identical cube trajectories at this task's loads. Torque current changes inversely with Kt; the consistent rewind's resistance change cancels the corresponding I²R change while limits are inactive.
- Kv ×4: still places the cube, but ends with about 185 mm of arm pose error. The current ceiling prevents the commanded final arm posture even though the object task succeeds.
- Current limit 6.6 A: loses arm control before grasping and knocks the cube off the table. This failed run is retained.
- Added 14 kg per arm: completes the task, with peak joint torque rising from 44.8 to 89.1 N·m and modeled peak winding temperature from 26.8 to 33.0 °C.

The complete machine-readable comparison, including hot start and undervoltage, is `showcase/public/data/manifest.json`. Per-stage checks and file hashes are in `showcase/public/data/protocol.json`.

These are one fixed 30-second attempt per design, not success-rate estimates. Gravity compensation uses each variant's actual modeled mass; path, gains and gripper drives remain fixed. Motors are Atlas design scenarios on Franka geometry, not manufacturer-identified Franka motors. Winding temperature is a lumped model estimate. No hardware-efficiency claim is made.

## Implementation

- `eval_scripts/showcase/transfer.py`: the Isaac Lab scene, bounded arm actuators, task-space trajectory, cube-specific finger contact sensors, telemetry and mesh export.
- `eval_scripts/showcase/run_variants.py`: snapshots the simulator source, launches at most two isolated processes, validates complete artifacts, and bounds shutdown without touching unrelated jobs.
- `eval_scripts/showcase/build_report.py`: validates replay sizes/rotations and measured stage outcomes, generates motor envelopes with the same FOC core, and prepares website data.
- `eval_scripts/showcase/render_replay.py`: optional offline video rendering of the recorded Isaac Lab poses. It does not simulate dynamics.
- `showcase/app/replay.tsx`: Three.js geometry/pose replay, orbit controls, contact indicators, object trace and synchronized comparison.
- `showcase/app/page.tsx`: variant selection, timeline, measured outcomes, motor parameters, charts, and the existing G1/ANYmal/Allegro recordings.

The replay uses frame-major, body-major little-endian float32 poses: `[x,y,z,qw,qx,qy,qz]`, 23 bodies, 1,500 frames. Frame 0 occurs at 0.0025 seconds and samples are 0.02 seconds apart. Position and quaternion interpolation only affect presentation. The cube state in telemetry additionally includes linear and angular velocity.

## Reproduce in Isaac Lab 2.1 / Isaac Sim 4.5

From an Isaac Lab installation with this project available:

```bash
PYTHONPATH=/path/to/atlas-actuator-isaac/atlas_actuators_ext \
OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 \
./isaaclab.sh -p /path/to/atlas-actuator-isaac/eval_scripts/showcase/transfer.py \
  --headless --variant nominal --duration 30 \
  --output /path/to/new-nominal-run --export-mesh
```

The output directory must not already exist. Other variants: `high_kv`, `very_high_kv`, `low_kv`, `low_current`, `heavy`, `hot`, `low_voltage`.

For a complete bounded sweep:

```bash
python3 eval_scripts/showcase/run_variants.py \
  --project /path/to/atlas-actuator-isaac \
  --isaaclab /workspace/IsaacLab --output /path/to/new-sweep
```

After copying the nominal run's `scene.json` to the sweep root:

```bash
python3 eval_scripts/showcase/build_report.py \
  --runs /path/to/new-sweep --suffix '' --public showcase/public
```

Exact original runtime scripts are retained per recorded run. The current reusable script also fixes mesh-unit conversion and bounds shutdown after artifacts are flushed; those fixes do not alter the recorded dynamics.

## Fixes found during development

1. The first explicit wrist configuration was numerically unstable: its damping and small reflected inertia were incompatible with the 2.5 ms integration step. The selected configuration uses stable armature/damping values, preserves gravity, and applies gravity feedforward inside the FOC torque limit.
2. Removing the full authored USD body transform also removed the Franka asset's centimetre scale. The exporter now removes only the rigid transform, preserving scale in metric geometry.
3. `SimulationApp.close()` waited on unused Replicator work. Disabling that wait alone did not resolve every shutdown hang. The reusable script allows 15 seconds for normal shutdown after closing all artifacts, then exits its own process. The sweep runner also has an artifact-aware fallback scoped to its own child process group.
4. The new website scaffold had dependency advisories. Compatible patched React, Vite, Vinext and Cloudflare packages were installed together. The package audit reported zero vulnerabilities after the update.

The shortfall chart reports the fraction of arm joints whose delivered torque misses its request by more than 10% or 0.5 N·m. Current telemetry is the maximum absolute q-axis current, Iq; it is not total current magnitude during field weakening. Finger glows indicate cube-specific normal contact, placed at finger body origins rather than exact contact points.
