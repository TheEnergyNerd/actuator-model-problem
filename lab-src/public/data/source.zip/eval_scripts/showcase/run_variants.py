"""Run a bounded, reproducible sweep without touching unrelated GPU jobs."""

from __future__ import annotations
import argparse
import array
import concurrent.futures
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import signal
import subprocess
import threading
import time

VARIANTS = (
    "nominal",
    "high_kv",
    "very_high_kv",
    "low_kv",
    "low_current",
    "heavy",
    "hot",
    "low_voltage",
)


def finite_tree(value):
    if isinstance(value, float):
        return math.isfinite(value)
    if isinstance(value, dict):
        return all(finite_tree(v) for v in value.values())
    if isinstance(value, list):
        return all(finite_tree(v) for v in value)
    return True


def validated_result(output: Path):
    """Only complete, finite artifacts count as a finished simulation."""
    try:
        result = json.loads((output / "result.json").read_text())
        n, bodies = result["frames"], result["bodies"]
        if (
            not isinstance(n, int)
            or not isinstance(bodies, int)
            or n < 1
            or bodies != 23
        ):
            return None
        blob = (output / "poses.bin").read_bytes()
        if len(blob) != n * bodies * 7 * 4:
            return None
        floats = array.array("f")
        floats.frombytes(blob)
        if not all(math.isfinite(v) for v in floats):
            return None
        samples = json.loads((output / "telemetry.json").read_text())
        if not finite_tree(samples) or not finite_tree(result):
            return None
        if len(samples) != n or not all(len(s.get("cube", [])) == 13 for s in samples):
            return None
        if (
            result.get("object_state_writes_during_episode") != 0
            or result.get("object_attachments") != 0
        ):
            return None
        return result
    except (OSError, ValueError, KeyError, TypeError):
        return None


def stop_child(process):
    """Terminate only the session created for this specific child."""
    if process.poll() is not None:
        return
    os.killpg(process.pid, signal.SIGTERM)
    try:
        process.wait(timeout=10)
    except subprocess.TimeoutExpired:
        os.killpg(process.pid, signal.SIGKILL)
        process.wait(timeout=10)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--project", type=Path, default=Path(__file__).resolve().parents[2]
    )
    parser.add_argument("--isaaclab", type=Path, default=Path("/workspace/IsaacLab"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, choices=[1, 2], default=2)
    parser.add_argument("--timeout", type=float, default=1200.0)
    parser.add_argument(
        "--variants", nargs="+", choices=VARIANTS, default=list(VARIANTS)
    )
    args = parser.parse_args()
    if (
        not math.isfinite(args.timeout)
        or args.timeout <= 0
        or len(set(args.variants)) != len(args.variants)
    ):
        parser.error("Timeout must be positive and finite; variants must be unique.")
    project = args.project.resolve()
    output = args.output.resolve()
    lab = args.isaaclab.resolve()
    source = project / "eval_scripts/showcase/transfer.py"
    if not source.exists():
        source = project / "eval_scripts/transfer.py"
    if not source.is_file() or not (lab / "isaaclab.sh").is_file():
        parser.error("Project source or Isaac Lab launcher was not found.")
    output.mkdir(parents=True, exist_ok=False)
    snapshot = output / "transfer.py"
    shutil.copy2(source, snapshot)
    source_hash = hashlib.sha256(snapshot.read_bytes()).hexdigest()
    env = os.environ | dict(
        PYTHONPATH=str(project / "atlas_actuators_ext"),
        OMP_NUM_THREADS="2",
        MKL_NUM_THREADS="2",
        PYTHONUNBUFFERED="1",
        OMNI_KIT_ACCEPT_EULA="YES",
    )
    lock = threading.Lock()
    status = {}

    def save(record):
        with lock:
            status[record["variant"]] = record
            temp = output / "status.tmp"
            temp.write_text(
                json.dumps(dict(source_sha256=source_hash, runs=status), indent=2)
            )
            temp.replace(output / "status.json")

    def run(variant):
        target = output / variant
        started = time.monotonic()
        done_at = None
        result = None
        forced_shutdown = False
        save(dict(variant=variant, status="running"))
        with (output / f"{variant}.log").open("w") as log:
            process = subprocess.Popen(
                [
                    str(lab / "isaaclab.sh"),
                    "-p",
                    str(snapshot),
                    "--headless",
                    "--variant",
                    variant,
                    "--output",
                    str(target),
                    *(["--export-mesh"] if variant == "nominal" else []),
                ],
                cwd=lab,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            try:
                while process.poll() is None:
                    if result is None and (target / "result.json").exists():
                        result = validated_result(target)
                        if result is not None:
                            done_at = time.monotonic()
                    if done_at is not None and time.monotonic() - done_at > 30:
                        forced_shutdown = True
                        stop_child(process)
                        break
                    if time.monotonic() - started > args.timeout:
                        forced_shutdown = True
                        stop_child(process)
                        break
                    time.sleep(0.5)
            finally:
                stop_child(process)
        result = result or validated_result(target)
        record = dict(
            variant=variant,
            status="completed" if result else "failed",
            exit_code=process.returncode,
            shutdown_required_termination=forced_shutdown,
            seconds=time.monotonic() - started,
            placement_success=result.get("placement_success") if result else None,
        )
        save(record)
        print(json.dumps(record), flush=True)
        return result is not None

    with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as pool:
        completed = list(pool.map(run, args.variants))
    return 0 if all(completed) else 1


if __name__ == "__main__":
    raise SystemExit(main())
