"""Validate recorded physics and publish compact, traceable replay data."""

from pathlib import Path
import argparse, json, math, shutil, hashlib, sys, zipfile
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "atlas_actuators_ext"))
from atlas_actuators.foc_core import FOCActuatorParams, step_current_lag

p = argparse.ArgumentParser()
p.add_argument("--runs", type=Path, required=True)
p.add_argument("--public", type=Path, required=True)
p.add_argument("--suffix", default="04")
args = p.parse_args()
root = Path(__file__).resolve().parents[2]
dest = args.public / "data"
dest.mkdir(parents=True, exist_ok=True)
variants = [
    (
        "nominal",
        "Nominal",
        "Nominal",
        "The reference motor: 48 V, 55 A, with the same task sequence used for every design.",
    ),
    (
        "high_kv",
        "High Kv rewind",
        "Kv ×2",
        "Twice the Kv, half the Kt. Fewer turns reduce winding resistance and inductance; the inverter current limit stays fixed.",
    ),
    (
        "very_high_kv",
        "Very high Kv rewind",
        "Kv ×4",
        "Four times the Kv, one quarter of the Kt. The fixed 55 A inverter now provides only a quarter of nominal peak torque.",
    ),
    (
        "low_kv",
        "Low Kv rewind",
        "Kv ×0.5",
        "Half the Kv, twice the Kt. More turns increase winding resistance and inductance and reduce the available speed.",
    ),
    (
        "low_current",
        "Current-limited motor",
        "Low current",
        "A 6.6 A inverter limit gives only 12% of nominal peak joint torque. This deliberately tests inadequate torque authority.",
    ),
    (
        "heavy",
        "Heavier arm hardware",
        "Heavy",
        "Adds 2 kg to each of seven moving arm links: 14 kg per arm. Rigid-body mass and inertia both change.",
    ),
    (
        "hot",
        "Hot start",
        "Hot start",
        "The same motor starts at 125 °C. Copper resistance, magnet strength and thermal current derating change together.",
    ),
    (
        "low_voltage",
        "Low bus voltage",
        "Low voltage",
        "A 6 V supply reduces voltage headroom and available torque at speed. This is an undervoltage stress test.",
    ),
]
manifest = dict(
    scene="/data/scene.json?v=metric-1",
    protocol="/data/protocol.json",
    source="/data/source.zip",
    variants=[],
)
audit = {}


def span(mask, dt=0.02):
    best = count = 0
    for v in mask:
        count = count + 1 if v else 0
        best = max(best, count)
    return best * dt


for key, label, short, description in variants:
    src = args.runs / (key + args.suffix)
    if not (src / "result.json").exists():
        continue
    r = json.loads((src / "result.json").read_text())
    tele = json.loads((src / "telemetry.json").read_text())
    poses = np.fromfile(src / "poses.bin", dtype="<f4").reshape(
        r["frames"], r["bodies"], 7
    )
    if not np.isfinite(poses).all():
        raise ValueError("Nonfinite body poses")
    if len(tele) != r["frames"]:
        raise ValueError("Mismatched frame count")
    qerr = float(np.max(abs(np.linalg.norm(poses[:, :, 3:7], axis=-1) - 1)))
    if qerr > 1e-4:
        raise ValueError("Invalid rotation quaternion")
    cube = np.array([x["cube"] for x in tele])
    ts = np.array([x["t"] for x in tele])
    contacts = np.array([x.get("contact_forces", [[0, 0, 0]] * 4) for x in tele])
    forces = np.linalg.norm(contacts, axis=-1)
    left = forces[:, :2].sum(-1)
    right = forces[:, 2:].sum(-1)
    target = np.array([0.48, 0.30, 0.33])
    err = np.linalg.norm(cube[-1, :2] - target[:2])
    lifted = span((ts > 6) & (ts < 14) & (cube[:, 2] > 0.50) & (left > 0.5)) >= 1.0
    qtarget = np.array([math.sqrt(0.5), 0, 0, math.sqrt(0.5)])
    angles = 2 * np.arccos(np.clip(abs(cube[:, 3:7] @ qtarget), 0, 1))
    rotated = (
        span(
            (ts > 11) & (ts < 15) & (angles < 0.15) & (cube[:, 2] > 0.50) & (left > 0.5)
        )
        >= 0.5
    )
    handed = (
        span(
            (ts > 18.5)
            & (ts < 23)
            & (cube[:, 2] > 0.50)
            & (forces[:, 2] > 0.15)
            & (forces[:, 3] > 0.15)
            & (left < 0.15)
        )
        >= 0.5
    )
    free_final = bool(np.max(left[ts > 28] + right[ts > 28]) < 0.15)
    placed = bool(r["placement_success"] and free_final)
    checks = dict(
        lifted=bool(lifted),
        rotated_90_degrees=bool(rotated),
        handoff_supported_by_right_only=bool(handed),
        placed_and_released=placed,
        full_sequence_success=bool(lifted and rotated and handed and placed),
        final_error_mm=float(err * 1000),
        max_quaternion_norm_error=qerr,
        max_contact_force_N=float(forces.max()),
        final_cube_speed_m_s=float(np.linalg.norm(cube[ts > 29, 7:10], axis=-1).max()),
        right_only_hold_seconds=span(
            (ts > 18.5)
            & (ts < 23)
            & (cube[:, 2] > 0.50)
            & (forces[:, 2] > 0.15)
            & (forces[:, 3] > 0.15)
            & (left < 0.15)
        ),
        replay_frames=r["frames"],
        body_count=r["bodies"],
    )
    checks["final_arm_pose_error_mm"] = float(
        np.max(
            np.linalg.norm(
                np.array(tele[-1]["tips"])
                - np.array([[0.40, -0.32, 0.75], [0.48, 0.30, 0.57]]),
                axis=-1,
            )
        )
        * 1000
    )
    checks["mean_torque_shortfall_fraction"] = float(
        np.mean([x["saturation"] for x in tele])
    )
    checks["peak_abs_Iq_A"] = float(max(x["current"] for x in tele))
    r["checks"] = checks
    dst = dest / key
    dst.mkdir(exist_ok=True)
    for f in ["poses.bin", "telemetry.json"]:
        shutil.copy2(src / f, dst / f)
    (dst / "result.json").write_text(json.dumps(r, indent=2))
    if (src / "transfer.py").exists():
        shutil.copy2(src / "transfer.py", dst / "transfer.py")
    hashes = {
        f.name: hashlib.sha256(f.read_bytes()).hexdigest()
        for f in dst.iterdir()
        if f.is_file()
    }
    kv = r["kv_scale"]
    I = 55 * r["current_scale"]
    temp = r["initial_winding_C"]
    volt = 6 if key == "low_voltage" else 48
    params = FOCActuatorParams(
        pole_pairs=10,
        lambda_m=(0.25 / 15) / kv,
        Rs=0.03 / kv**2,
        Ld=85e-6 / kv**2,
        Lq=85e-6 / kv**2,
        gear_ratio=12.0,
        I_peak=I,
        I_cont=28 * r["current_scale"],
        V_bus=volt,
    )
    omega = np.linspace(0, 30, 121)
    zero = np.zeros_like(omega)
    torque, *_ = step_current_lag(
        params,
        np.full_like(omega, 1000),
        omega,
        zero,
        zero,
        np.full_like(omega, temp),
        0.0025,
    )
    v = dict(
        id=key,
        label=label,
        short=short,
        description=description,
        kv=45 / math.pi / (0.25 / kv),
        kt=0.25 / kv,
        current=I,
        mass=r["added_mass_per_arm_kg"],
        voltage=volt,
        temperature=temp,
        peakTorque=0.25 / kv * I * 12 * 0.9,
        resistance=0.03 / kv**2,
        result=r,
        envelope=[dict(speed=float(w), torque=float(v)) for w, v in zip(omega, torque)],
    )
    if key == "nominal":
        v["observed"] = (
            "The reference passes all four measured stages, including a right-only handoff and contact-free placement."
        )
    elif key in ["high_kv", "low_kv"]:
        v["observed"] = (
            f"The task stays inside this motor's limits. Peak torque current is {checks['peak_abs_Iq_A']:.1f} A; the cube trajectory matches the nominal recording."
        )
    elif key == "very_high_kv":
        v["observed"] = (
            f"The cube is placed, but the worst final arm pose misses its command by {checks['final_arm_pose_error_mm']:.0f} mm. Peak current reaches {checks['peak_abs_Iq_A']:.1f} A."
        )
    elif key == "heavy":
        v["observed"] = (
            f"The task still completes. Peak torque rises to {r['peak_torque']:.1f} N·m and the hottest winding reaches {r['peak_temperature']:.1f} °C."
        )
    elif key == "low_current":
        v["observed"] = (
            "The arm loses control before grasping and knocks the cube off the table. Cooling is not the limiting factor in this run."
        )
    elif key == "hot":
        v["observed"] = (
            f"Starts at 125 °C and still completes this task. Peak torque current rises to {checks['peak_abs_Iq_A']:.1f} A as the hotter motor's magnet flux falls."
        )
    elif key == "low_voltage":
        v["observed"] = (
            "At this slow motion, even the 6 V bus stays within its voltage limit. The recorded trajectory matches nominal; high-speed capability is not established."
        )
    manifest["variants"].append(v)
    audit[key] = dict(checks=checks, sha256=hashes)
# Compact the original physics meshes to ~10 micrometre visual precision only.
scene = json.loads((args.runs / "scene.json").read_text())
for m in scene["meshes"]:
    m["vertices"] = [round(v, 6) for v in m["vertices"]]
(dest / "scene.json").write_text(json.dumps(scene, separators=(",", ":")))
(dest / "manifest.json").write_text(json.dumps(manifest, separators=(",", ":")))
protocol = dict(
    engine="Isaac Lab 2.1 / Isaac Sim 4.5 / PhysX on RunPod L40S",
    control="Scripted task-space poses, differential IK at 100 Hz, explicit Atlas FOC arm actuators at 400 Hz; physical implicit gripper drives capped at 30 N.",
    recording="23 rigid-body poses at 50 Hz, float32 little-endian, frame-major/body-major, [x,y,z,qw,qx,qy,qz]. Linear position and quaternion slerp interpolation in the viewer.",
    replay_time="Frame 0 is at 0.0025 seconds; successive frames are 0.02 seconds apart.",
    scope="One fixed, continuous 30-second demonstration per variant. This is not a statistical robustness study, learned dexterous policy, Rubik solver or hardware validation.",
    source_of_motion="Only robot joint targets and bounded feedforward efforts are commanded after initialization. The object has no actuator or attachment and no pose, velocity or state writes during the episode.",
    cube=dict(
        size_m=0.06,
        mass_kg=0.12,
        initial_position_m=[0.45, -0.30, 0.333],
        target_position_m=[0.48, 0.30, 0.33],
    ),
    actuators=dict(
        shoulder_gear=12,
        wrist_gear=4,
        gear_efficiency=0.9,
        shoulder_armature=0.10,
        wrist_armature=0.08,
        nominal_Kt_Nm_per_A=0.25,
        nominal_Kv_phase_peak_rpm_per_V=45 / math.pi / 0.25,
        nominal_R_ohm=0.03,
        nominal_Ld_Lq_H=85e-6,
        current_limit_A=55,
        thermal_R_Kper_W=1.8,
        thermal_C_Jper_K=80,
        thermal_derating_starts_C=120,
        gripper_force_limit_N=30,
    ),
    design_rules="Fixed-copper rewind: Kt inversely proportional to Kv; R and L inversely proportional to Kv squared. Added mass is distributed as 2 kg on each moving arm link, with inertia scaled by the same density factor; COM offsets and geometry stay fixed. The initial state, path, gains and gripper drives are shared across variants. Gravity compensation is recomputed from each variant’s actual modeled mass; this is a model-aware controller, not a frozen nominal gravity model.",
    success_checks="Lift: >=1 s above 0.5 m with left contact >0.5 N. Rotate: >=0.5 s within 0.15 rad of 90-degree yaw while left-supported. Handoff: >=0.5 s above 0.5 m, each right finger >0.15 N and left total <0.15 N between 18.5 and 23 s. Place: XY error <5 cm, Z within 2 cm of 0.33 m, max speed <3 cm/s over the final second, and both grippers contact-free over final 2 s.",
    current_telemetry="current is the largest absolute q-axis torque current, Iq, across the arm motors; it is not the total current magnitude during field weakening.",
    contact_visualization="Finger glows indicate measured normal force above 0.15 N against the cube; glow origins are finger body origins, not precise contact points.",
    limits=[
        "The FOC fast model approximates closed-loop current response; it does not simulate every PWM cycle.",
        "Temperature uses a lumped winding model; magnet temperature shares that state.",
        "Arm electrical parameters are Atlas design scenarios on Franka geometry, not manufacturer-validated Franka motors.",
        "Per-group ideal 48 V buses have no shared pack sag in the nominal case.",
        "The browser shows a recorded simulation; motor selections load separate runs.",
        "Meshes use a presentation material palette; rigid-body trajectories are unmodified.",
    ],
    attribution={
        "Isaac Lab": "https://github.com/isaac-sim/IsaacLab",
        "presentation_reference": "https://dex-rubik-cube.yanjieze.com/",
    },
    runs=audit,
)
(dest / "protocol.json").write_text(json.dumps(protocol, indent=2))
shutil.copy2(root / "eval_scripts/showcase/transfer.py", dest / "transfer.py")
with zipfile.ZipFile(dest / "source.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for f in (root / "eval_scripts/showcase").glob("*.py"):
        z.write(f, "eval_scripts/showcase/" + f.name)
    for f in (root / "atlas_actuators_ext/atlas_actuators").glob("*.py"):
        z.write(f, "atlas_actuators_ext/atlas_actuators/" + f.name)
    z.write(dest / "protocol.json", "protocol.json")
    z.write(root / "SHOWCASE.md", "SHOWCASE.md")
print(
    json.dumps({v["id"]: v["result"]["checks"] for v in manifest["variants"]}, indent=2)
)
