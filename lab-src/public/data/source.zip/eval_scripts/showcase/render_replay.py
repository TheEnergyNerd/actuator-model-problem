"""Render the exported Isaac Lab body poses; this does not run new physics."""

import os

os.environ.setdefault("PYOPENGL_PLATFORM", "egl")
from pathlib import Path
import argparse, json, math
import numpy as np

# Compatibility for the archived pyrender 0.1.45 renderer on NumPy 2.
if not hasattr(np, "infty"):
    np.infty = np.inf
import pyglet

pyglet.options["headless"] = True
import trimesh, pyrender, imageio.v2 as imageio
from PIL import Image, ImageDraw, ImageFont

p = argparse.ArgumentParser()
p.add_argument("--data", type=Path, required=True)
p.add_argument("--run", default="nominal")
p.add_argument("--out", type=Path, required=True)
p.add_argument("--still", type=float)
p.add_argument("--close", action="store_true")
a = p.parse_args()
a.out.mkdir(parents=True, exist_ok=True)
spec = json.loads((a.data / "scene.json").read_text())
r = json.loads((a.data / a.run / "result.json").read_text())
samples = json.loads((a.data / a.run / "telemetry.json").read_text())
poses = np.fromfile(a.data / a.run / "poses.bin", dtype="<f4").reshape(
    r["frames"], r["bodies"], 7
)
scene = pyrender.Scene(
    bg_color=[0.902, 0.914, 0.882, 1.0], ambient_light=[0.42, 0.42, 0.40]
)
nodes = []
for m in spec["meshes"]:
    b = m["body"]
    finger = b % 11 >= 9
    color = (
        [0.20, 0.23, 0.21, 1.0]
        if finger
        else ([0.65, 0.71, 0.63, 1.0] if b < 11 else [0.86, 0.85, 0.79, 1.0])
    )
    mesh = trimesh.Trimesh(
        vertices=np.array(m["vertices"]).reshape(-1, 3),
        faces=np.array(m["indices"]).reshape(-1, 3),
        process=False,
    )
    mat = pyrender.MetallicRoughnessMaterial(
        baseColorFactor=color, metallicFactor=0.25, roughnessFactor=0.42
    )
    n = scene.add(pyrender.Mesh.from_trimesh(mesh, material=mat, smooth=True))
    nodes.append((b, n))


def addbox(size, pos, color):
    mesh = trimesh.creation.box(extents=size)
    mat = pyrender.MetallicRoughnessMaterial(
        baseColorFactor=[*color, 1], roughnessFactor=0.8
    )
    trans = np.eye(4)
    trans[:3, 3] = pos
    return scene.add(pyrender.Mesh.from_trimesh(mesh, material=mat), pose=trans)


addbox(spec["table"]["size"], spec["table"]["position"], [0.61, 0.68, 0.58])
addbox([200, 200, 0.01], [0, 0, -0.012], [0.86, 0.88, 0.82])
for xy, col in [
    ([0.45, -0.30], [0.83, 0.67, 0.33]),
    ([0.48, 0.30], [0.21, 0.43, 0.32]),
]:
    for d in [-1, 1]:
        addbox([0.12, 0.002, 0.001], [xy[0], xy[1] + d * 0.06, 0.301], col)
        addbox([0.002, 0.12, 0.001], [xy[0] + d * 0.06, xy[1], 0.301], col)
cube = trimesh.creation.box(extents=[0.06] * 3)
cube.visual.face_colors = np.repeat(
    np.array(
        [
            [225, 91, 28, 255],
            [244, 179, 50, 255],
            [244, 231, 189, 255],
            [72, 137, 114, 255],
            [206, 68, 32, 255],
            [237, 115, 40, 255],
        ],
        dtype=np.uint8,
    ),
    2,
    axis=0,
)
nodes.append((22, scene.add(pyrender.Mesh.from_trimesh(cube, smooth=False))))


def lookat(eye, target):
    eye = np.array(eye)
    target = np.array(target)
    z = eye - target
    z /= np.linalg.norm(z)
    x = np.cross([0, 0, 1], z)
    x /= np.linalg.norm(x)
    y = np.cross(z, x)
    M = np.eye(4)
    M[:3, :3] = np.stack([x, y, z], -1)
    M[:3, 3] = eye
    return M


cam = scene.add(
    pyrender.PerspectiveCamera(yfov=math.radians(36)),
    pose=lookat([1.95, 1.8, 1.55], [0.37, 0, 0.5]),
)
for eye, intensity in [([1, -2, 4], 2.7), ([-2, 1, 3], 1.6)]:
    scene.add(
        pyrender.DirectionalLight(color=[1.0, 0.98, 0.94], intensity=intensity),
        pose=lookat(eye, [0.4, 0, 0.4]),
    )
renderer = pyrender.OffscreenRenderer(1280, 720)
fontdir = Path("/usr/share/fonts/truetype/dejavu")
font = ImageFont.truetype(str(fontdir / "DejaVuSans.ttf"), 19)
small = ImageFont.truetype(str(fontdir / "DejaVuSans.ttf"), 13)
bold = ImageFont.truetype(str(fontdir / "DejaVuSans-Bold.ttf"), 24)


def frame(i, close=False):
    if close:
        scene.set_pose(cam, pose=lookat([1.02, 0.58, 0.99], [0.48, -0.02, 0.64]))
    else:
        scene.set_pose(cam, pose=lookat([1.95, 1.8, 1.55], [0.37, 0, 0.5]))
    for bi, node in nodes:
        row = poses[i, bi]
        M = trimesh.transformations.quaternion_matrix(row[3:7])
        M[:3, 3] = row[:3]
        scene.set_pose(node, pose=M)
    rgb, _ = renderer.render(scene, flags=pyrender.RenderFlags.SHADOWS_DIRECTIONAL)
    im = Image.fromarray(rgb)
    d = ImageDraw.Draw(im)
    d.rectangle([0, 0, 1280, 66], fill="#f3f2ed")
    d.text((28, 16), "ATLAS / ACTUATOR LAB", font=bold, fill="#18312d")
    d.text(
        (805, 25),
        "ISAAC LAB PHYSICS / RECORDED-POSE RENDER",
        font=small,
        fill="#536d58",
    )
    s = samples[i]
    d.rectangle([0, 650, 1280, 720], fill="#f3f2ed")
    d.text(
        (28, 666),
        f"{s['t']:05.2f} s   /   {s['phase'].upper()}",
        font=font,
        fill="#18312d",
    )
    forces = [np.linalg.norm(x) for x in s.get("contact_forces", [[0, 0, 0]] * 4)]
    d.text(
        (410, 662),
        f"LEFT CONTACT  {sum(forces[:2]):.1f} N     RIGHT CONTACT  {sum(forces[2:]):.1f} N",
        font=small,
        fill="#536d58",
    )
    d.text(
        (410, 685),
        f'MAX TORQUE  {s["torque"]:.1f} Nm     WINDING  {s["temperature"]:.1f} C',
        font=small,
        fill="#536d58",
    )
    d.text((1040, 673), a.run.upper(), font=font, fill="#19735e")
    d.line(
        [(28, 715), (28 + 1224 * (i / (len(poses) - 1)), 715)], fill="#19735e", width=3
    )
    return np.array(im)


if a.still is not None:
    i = min(len(poses) - 1, int(a.still * 50))
    Image.fromarray(frame(i, a.close)).save(a.out / f"{a.run}_{a.still:g}.png")
else:
    with imageio.get_writer(
        str(a.out / f"{a.run}.mp4"),
        fps=25,
        codec="libx264",
        quality=8,
        macro_block_size=1,
    ) as writer:
        for i in range(0, len(poses), 2):
            writer.append_data(frame(i, 12 <= i / 50 <= 20))
            if i % 250 == 0:
                print("Rendered", i, flush=True)
    for t in [8, 14, 18, 21, 29]:
        Image.fromarray(frame(int(t * 50), 12 <= t <= 20)).save(
            a.out / f"{a.run}_{t}.png"
        )
renderer.delete()
